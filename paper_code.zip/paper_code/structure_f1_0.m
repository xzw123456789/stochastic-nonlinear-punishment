clear; clc; close all;

%% ==================== 参数设置 ====================
k = 5;       % 平均度
alpha = 0.2; % 合作者成本
beta = 0.5;  % 惩罚强度

% r = 2.0 和 r = 3.0
r_values = [2, 3];

%% ==================== SCI 论文图形标准设置 ====================
font_name = 'Times New Roman';
font_size_axis = 14;
line_width_curve = 2.5;
line_width_axis = 1.0;

%% ==================== 颜色设置（Nature风格） ====================
alpha_val = 0.65;
red_color = [0.92, 0.10, 0.10];      % 区域1
blue_color = [0.12, 0.47, 0.71];     % 区域2
gray_color = [0.75, 0.75, 0.75];     % 交叉区域（浅灰色，表示未定状态）

% 混合白色模拟透明效果
red_alpha = red_color * alpha_val + [1,1,1] * (1-alpha_val);
blue_alpha = blue_color * alpha_val + [1,1,1] * (1-alpha_val);
gray_alpha = gray_color * alpha_val + [1,1,1] * (1-alpha_val);

curve_color_r2 = [0.4, 0.4, 0.5];        % r=2.0 曲线颜色（灰紫色，柔和）
curve_color_r3 = [0.9, 0.9, 0.9];        % r=3.0 曲线颜色（白色）

%% ==================== 数据计算 ====================
p_vals = linspace(0, 1, 500);
delta_vals = linspace(0.001, 1, 500);
[P, DELTA] = meshgrid(p_vals, delta_vals);

% 定义 f(1) 的表达式
f1_fun = @(p, delta, r) (beta./(k .* delta)) .* ...
    (p .* (1 + delta .* ((k-2)/(k-1))).^(k-1) .* (delta+2) ...
    - (1-p) .* (1 - delta .* ((k-2)/(k-1))).^(k-1) .* (2-delta) ...
    + p .* (1+delta).^k .* (k+1) ...
    - (1-p) .* (1-delta).^k .* (k+1) ...
    + (k+1) .* (1-2*p)) ...
    - (k+1).*(1+alpha) + r;

%% ==================== 计算两个r值的F1 ====================
F1_r2 = arrayfun(@(p, delta) f1_fun(p, delta, 2), P, DELTA);
F1_r3 = arrayfun(@(p, delta) f1_fun(p, delta, 3), P, DELTA);

%% ==================== 提取等值线数据 ====================
% 提取 r=2.0 的等值线
figure('Visible', 'off');
[C_r2, ~] = contour(P, DELTA, F1_r2, [0 0]);
close;

idx = 1; p_r2 = []; delta_r2 = [];
while idx < size(C_r2, 2)
    n_points = C_r2(2, idx);
    p_r2 = [p_r2, C_r2(1, idx+1:idx+n_points)];
    delta_r2 = [delta_r2, C_r2(2, idx+1:idx+n_points)];
    idx = idx + n_points + 1;
end
[delta_r2, sort_idx] = sort(delta_r2);
p_r2 = p_r2(sort_idx);

% 提取 r=3.0 的等值线
figure('Visible', 'off');
[C_r3, ~] = contour(P, DELTA, F1_r3, [0 0]);
close;

idx = 1; p_r3 = []; delta_r3 = [];
while idx < size(C_r3, 2)
    n_points = C_r3(2, idx);
    p_r3 = [p_r3, C_r3(1, idx+1:idx+n_points)];
    delta_r3 = [delta_r3, C_r3(2, idx+1:idx+n_points)];
    idx = idx + n_points + 1;
end
[delta_r3, sort_idx] = sort(delta_r3);
p_r3 = p_r3(sort_idx);

%% ==================== 创建图形 - 16x12厘米 ====================
fig = figure('Units', 'centimeters', 'Position', [5, 5, 16, 12]);
set(fig, 'Color', 'w');

hold on;

%% ==================== 区域填充 ====================
state = zeros(size(P));
state(F1_r2 < 0 & F1_r3 < 0) = 1;  % 红色区域
state(F1_r2 < 0 & F1_r3 > 0) = 2;  % 灰色（交叉区域）
state(F1_r2 > 0 & F1_r3 > 0) = 3;  % 蓝色区域

contourf(P, DELTA, state, [0.5, 1.5, 2.5, 3.5], 'LineStyle', 'none');
colormap([red_alpha; gray_alpha; blue_alpha]);

%% ==================== 绑制边界曲线 ====================
h1 = plot(p_r2, delta_r2, '-', 'Color', curve_color_r2, 'LineWidth', line_width_curve);
h2 = plot(p_r3, delta_r3, '--', 'Color', curve_color_r3, 'LineWidth', line_width_curve);

%% ==================== 坐标轴设置 ====================
ax = gca;
set(ax, 'FontName', font_name, 'FontSize', font_size_axis, 'FontWeight', 'bold');
set(ax, 'LineWidth', line_width_axis);
set(ax, 'LabelFontSizeMultiplier', 1.2);  % 标签大小为刻度字体的1.2倍

% 关闭自带的 Box，以去除冗余刻度
set(ax, 'Box', 'off'); 
set(ax, 'Layer', 'top');
set(ax, 'TickDir', 'in');
set(ax, 'TickLength', [0.02, 0.02]);

% 设定坐标范围
x_limits = [0 1];
y_limits = [0 1];
xlim(x_limits);
ylim(y_limits);
set(ax, 'XTick', 0:0.2:1);
set(ax, 'YTick', 0:0.2:1);

% 手动绘制上方和右方的边界线（不带刻度）
line(x_limits, [y_limits(2), y_limits(2)], 'Color', 'k', 'LineWidth', line_width_axis);
line([x_limits(2), x_limits(2)], y_limits, 'Color', 'k', 'LineWidth', line_width_axis);

xlabel('$p$', 'Interpreter', 'latex');
ylabel('$\delta$', 'Interpreter', 'latex');

%% ==================== 图例设置 ====================
lgd = legend([h1, h2], {'$r = 2.0$', '$r = 3.0$'}, ...
    'Interpreter', 'latex', ...
    'FontSize', 12, ...
    'FontWeight', 'bold', ...
    'Location', 'northeast', ...
    'Box', 'on', ...
    'EdgeColor', [0.3, 0.3, 0.3]);

hold off;

% 导出（取消注释使用）
% saveas(gcf, 'Fig6_Structured.png');
% print(gcf, 'Fig6_Structured', '-depsc', '-r300');