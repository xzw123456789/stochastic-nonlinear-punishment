clc;
clear;
close all;
% 固定参数
G = 5;
alpha = 0.2;
beta = 0.5;
r = 4;
% 定义 f(x) 函数
f = @(x, p, delta) (r / G) - 1 - alpha + (beta / ((G - 1) * delta)) * ...
    (1 - 2 * p + p * (1 + delta * x).^(G - 1) - (1 - p) * (1 - delta * x).^(G - 1));
% 定义 p 和 delta 的范围
p_vals = linspace(0, 1, 50);
delta_vals = linspace(0.01, 1, 50);
% 初始化结果存储
roots_result = NaN(length(p_vals), length(delta_vals));
% 遍历 p 和 delta,寻找 f(x)=0 的解
for i = 1:length(p_vals)
    p = p_vals(i);
    for j = 1:length(delta_vals)
        delta = delta_vals(j);
        func = @(x) f(x, p, delta);
        f0 = func(0);
        f1 = func(1);
        if f0 * f1 < 0
            try
                root = fzero(func, [0, 1]);
                if root >= 0 && root <= 1
                    roots_result(i, j) = root;
                end
            catch
            end
        else
            x0_list = [0.5, 0.1, 0.9, 0.3, 0.7];
            for x0 = x0_list
                try
                    [root, fval, exitflag] = fsolve(func, x0, optimoptions('fsolve', 'Display', 'off', 'TolFun', 1e-10));
                    if root >= 0 && root <= 1 && abs(fval) < 1e-8 && exitflag > 0
                        roots_result(i, j) = root;
                        break;
                    end
                catch
                    continue;
                end
            end
        end
    end
end
%% 绑图 - 统一尺寸16x12厘米
figure('Units', 'centimeters', 'Position', [5, 5, 16, 12]);
h = imagesc(p_vals, delta_vals, roots_result');
set(h, 'AlphaData', ~isnan(roots_result'));
set(gca, 'YDir', 'normal');
set(gca, 'Color', [1 1 1]);
% 自定义colormap
n = 256;
blue = [0.2, 0.4, 0.8];
light_yellow = [1, 1, 0.85];
red = [0.8, 0.2, 0.2];
cmap = [linspace(blue(1), light_yellow(1), n/2)', linspace(blue(2), light_yellow(2), n/2)', linspace(blue(3), light_yellow(3), n/2)';
        linspace(light_yellow(1), red(1), n/2)', linspace(light_yellow(2), red(2), n/2)', linspace(light_yellow(3), red(3), n/2)'];
colormap(cmap);
% 颜色条
cb = colorbar;
cb.Label.String = 'Roots of $f(x)$';
cb.Label.Interpreter = 'latex';
cb.Label.FontSize = 14;
cb.FontWeight = 'bold';
%% 统一字体和标签设置
ax = gca;
set(ax, 'FontName', 'Times New Roman', 'FontSize', 14, 'LineWidth', 1, 'FontWeight', 'bold');
set(ax, 'LabelFontSizeMultiplier', 1.2);  % 标签大小为刻度字体的1.2倍
xlabel('$p$', 'Interpreter', 'latex');
ylabel('$\delta$', 'Interpreter', 'latex');
xlim([0 1]);
ylim([0.01 1]);
%% 去掉右侧和上侧刻度线,保留边框
set(ax, 'Box', 'off');
xL = xlim;
yL = ylim;
line([xL(2) xL(2)], [yL(1) yL(2)], 'Color', 'k', 'LineWidth', 1);
line([xL(1) xL(2)], [yL(2) yL(2)], 'Color', 'k', 'LineWidth', 1);