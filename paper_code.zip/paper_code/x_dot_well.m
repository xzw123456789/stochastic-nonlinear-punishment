%% ==================== Figure 2a ====================
clear all
% Define Parameters
r = 1.5;
delta = 0.8;
p = 0.5;
G = 5;
pc = zeros(101, 1);
for i = 1:101
    x = 0.01 * (i - 1);
    pc(i, 1) = x * (1 - x) * ((r/G) - 1 - 0.2 + (0.5/((G-1) * delta)) * (1 - 2 * p + p * (1 + delta * x)^(G-1) - (1 - p) * (1 - delta * x)^(G-1)));
end
bb = 0:0.01:1;

%% ========== Fixed Size Settings (16x12 cm) ==========
fig = figure;
fig_width = 16;
fig_height = 12;
set(fig, 'Units', 'centimeters');
set(fig, 'Position', [5, 5, fig_width, fig_height]);
set(fig, 'PaperUnits', 'centimeters');
set(fig, 'PaperSize', [fig_width, fig_height]);
set(fig, 'PaperPosition', [0, 0, fig_width, fig_height]);

%% ========== Plotting ==========
ax1 = axes('Units', 'normalized', 'Position', [0.15 0.15 0.8 0.8]);
plot(ax1, bb, pc(:,1), 'Color', [0.1, 0.5, 0.95], 'LineWidth', 6)
hold on;
line(ax1, [0, 1], [0, 0], 'Color', [0, 0.27, 0.525], 'LineStyle', '-', 'LineWidth', 3.5);
hold off;

% 统一标签设置 (FontSize 18)
ylabel(ax1, '$\dot{x}$', 'Interpreter', 'latex', 'FontSize', 18);
xlabel(ax1, '$x$', 'Interpreter', 'latex', 'FontSize', 18);

% 统一坐标轴设置
set(ax1, 'FontName', 'Arial');
set(ax1, 'FontSize', 12);
set(ax1, 'FontWeight', 'bold');  % 刻度值加粗
set(ax1, 'LabelFontSizeMultiplier', 2);  % 标签相对刻度值放大1.5倍
set(ax1, 'LineWidth', 0.8);
set(ax1, 'TickDir', 'in');
set(ax1, 'Box', 'off');

xlim(ax1, [0 1]);
ylim(ax1, [-0.18 0.02]);
set(ax1, 'YTick', -0.16:0.04:0);
ax1.YAxis.TickLabelGapOffset = 5;

%% ========== Secondary Axes for Border ==========
ax2 = axes('Position', get(ax1, 'Position'), ...
           'Color', 'none', ...
           'XTick', [], ...
           'YTick', [], ...
           'Box', 'on', ...
           'LineWidth', 0.8, ...
           'XLim', [0 1], ...
           'YLim', [-0.18 0.02], ...
           'Handlevisibility', 'off', ... 
           'HitTest', 'off');
linkaxes([ax1, ax2], 'xy');

%% ========== Export ==========
exportgraphics(fig, 'fig2a.eps', 'ContentType', 'vector');
