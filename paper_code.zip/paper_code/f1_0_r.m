clear; clc; close all;
% 固定参数
G = 5;
alpha = 0.2;
beta = 0.5;
r = 4.0;
% 定义p和δ的范围
p_vals = linspace(0, 1, 500);
delta_vals = linspace(0.001, 1, 500);
[P, DELTA] = meshgrid(p_vals, delta_vals);
% 定义f(1)函数
f1_fun = @(r,p,delta) (r./G) - 1 - alpha + (beta./((G-1).*delta)) .* ...
    (1 - 2.*p + p.*(1+delta).^(G-1) - (1 - p).*(1 - delta).^(G-1));
F = f1_fun(r, P, DELTA);
%% 提取等值线坐标
figure;
[C, ~] = contour(P, DELTA, F, [0 0]);
close;
idx = 1;
p_curve = [];
delta_curve = [];
while idx < size(C, 2)
    n_points = C(2, idx);
    p_curve = [p_curve, C(1, idx+1:idx+n_points)];
    delta_curve = [delta_curve, C(2, idx+1:idx+n_points)];
    idx = idx + n_points + 1;
end
[delta_curve, sort_idx] = sort(delta_curve);
p_curve = p_curve(sort_idx);
%% 配色方案
blue_color = [0.12, 0.47, 0.71];
red_color = [0.92, 0.10, 0.10];
curve_color = [0.9, 0.9, 0.9];
alpha_val = 0.65;
blue_alpha = blue_color * alpha_val + [1,1,1] * (1-alpha_val);
red_alpha = red_color * alpha_val + [1,1,1] * (1-alpha_val);
%% 绑图 - 统一尺寸16x12厘米
figure('Units', 'centimeters', 'Position', [5, 5, 16, 12]);
hold on;
% 填充区域
p_right = [p_curve, 1, 1, 0, p_curve(1)];
delta_right = [delta_curve, 1, 0, 0, delta_curve(1)];
fill(p_right, delta_right, blue_alpha, 'EdgeColor', 'none');
p_left = [p_curve, 0, 0, p_curve(1)];
delta_left = [delta_curve, 1, 0, delta_curve(1)];
fill(p_left, delta_left, red_alpha, 'EdgeColor', 'none');
plot(p_curve, delta_curve, 'Color', curve_color, 'LineWidth', 2.5);
%% 统一字体和标签设置
ax = gca;
set(ax, 'FontName', 'Times New Roman', 'FontSize', 14, 'LineWidth', 1, 'FontWeight', 'bold');
set(ax, 'LabelFontSizeMultiplier', 1.2);  % 标签大小为刻度字体的1.2倍
xlabel('$p$', 'Interpreter', 'latex');
ylabel('$\delta$', 'Interpreter', 'latex');
xlim([0 1]);
ylim([0 1]);
%% 去掉右边和上边刻度线，保留边框
set(ax, 'Box', 'off');
xL = xlim; 
yL = ylim;
line([xL(2) xL(2)], [yL(1) yL(2)], 'Color', 'k', 'LineWidth', 1);
line([xL(1) xL(2)], [yL(2) yL(2)], 'Color', 'k', 'LineWidth', 1);
% 图例
h1 = fill(nan, nan, blue_alpha, 'EdgeColor', 'none');
h2 = fill(nan, nan, red_alpha, 'EdgeColor', 'none');
legend([h1, h2], {'Bistability', 'All-D'}, 'Location', 'northeast', 'FontSize', 12, 'FontWeight', 'bold');
hold off;