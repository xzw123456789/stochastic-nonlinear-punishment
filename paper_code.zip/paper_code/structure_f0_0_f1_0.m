clear; clc; close all;

% 固定参数（根据需要调整）
k = 5;       % 平均度
alpha = 0.2; % 合作者成本
r = 1.5;     % 公共物品增值因子
beta = 8.5;  % 惩罚强度

% 定义参数范围
p_vals = linspace(0, 1, 500);         % 惩罚概率 p 的取值
delta_vals = linspace(0.001, 1, 500); % 协同/折扣参数 delta 的取值
[P, DELTA] = meshgrid(p_vals, delta_vals);

% 定义 f(1) 的表达式
f1_fun = @(p, delta) (beta./(k .* delta)) .* ...
    (p .* (1 + delta .* ((k-2)/(k-1))).^(k-1) .* (delta + 2) ...
    - (1-p) .* (1 - delta .* ((k-2)/(k-1))).^(k-1) .* (2 - delta) ...
    + p .* (1 + delta).^k .* (k+1) ...
    - (1-p) .* (1 - delta).^k .* (k+1) ...
    + (k+1) .* (1-2*p)) ...
    - (k+1).*(1+alpha) + r;

% 定义 f(0) 的表达式
f0_fun = @(p, delta) (beta./(k .* delta)) .* ...
    (p .* (delta + k) ...
    - (1-p) .* (k - delta) ...
    + p .* (1 + delta) .* (1 + (1/(k-1))*delta).^(k-1) ...
    - (1-p) .* (1 - delta) .* (1 - (1/(k-1))*delta).^(k-1) ...
    + (k+1) .* (1-2*p)) ...
    - (k+1).*(1+alpha) + r;

% 计算 f(1) 和 f(0)
F1 = arrayfun(f1_fun, P, DELTA);
F0 = arrayfun(f0_fun, P, DELTA);

%% 提取等值线坐标
figure;
[C1, ~] = contour(P, DELTA, F1, [0 0]);
hold on;
[C0, ~] = contour(P, DELTA, F0, [0 0]);
close;

% 解析 f(1)=0 等值线
idx = 1;
p_curve1 = [];
delta_curve1 = [];
while idx < size(C1, 2)
    n_points = C1(2, idx);
    p_curve1 = [p_curve1, C1(1, idx+1:idx+n_points)];
    delta_curve1 = [delta_curve1, C1(2, idx+1:idx+n_points)];
    idx = idx + n_points + 1;
end

% 解析 f(0)=0 等值线
idx = 1;
p_curve0 = [];
delta_curve0 = [];
while idx < size(C0, 2)
    n_points = C0(2, idx);
    p_curve0 = [p_curve0, C0(1, idx+1:idx+n_points)];
    delta_curve0 = [delta_curve0, C0(2, idx+1:idx+n_points)];
    idx = idx + n_points + 1;
end

% 按delta排序
[delta_curve1, sort_idx1] = sort(delta_curve1);
p_curve1 = p_curve1(sort_idx1);
[delta_curve0, sort_idx0] = sort(delta_curve0);
p_curve0 = p_curve0(sort_idx0);

%% 绑图 - 16x12厘米
figure('Units', 'centimeters', 'Position', [5, 5, 16, 12]);
hold on;

% 定义颜色（Nature风格配色）
alpha_val = 0.65;                     % 透明度
red_color = [0.92, 0.10, 0.10];      % All-D区域（鲜艳红色）
blue_color = [0.12, 0.47, 0.71];     % Bistability区域（深蓝色）
gold_color = [0.99, 0.75, 0.18];     % All-C区域（金黄色）
curve_color = [0.9, 0.9, 0.9];       % 曲线颜色（浅灰色）

% 混合白色模拟透明效果
red_alpha = red_color * alpha_val + [1,1,1] * (1-alpha_val);
blue_alpha = blue_color * alpha_val + [1,1,1] * (1-alpha_val);
gold_alpha = gold_color * alpha_val + [1,1,1] * (1-alpha_val);

% 创建状态矩阵
state = zeros(size(P));
state(F0 < 0 & F1 < 0) = 1;  % All-D
state(F0 < 0 & F1 > 0) = 3;  % Bistability
state(F0 > 0 & F1 > 0) = 2;  % All-C

% 使用contourf填充区域
contourf(P, DELTA, state, [0.5, 1.5, 2.5, 3.5], 'LineStyle', 'none');

% 设置颜色映射
colormap([red_alpha; gold_alpha; blue_alpha]);

% 绑制等值线
plot(p_curve1, delta_curve1, 'Color', curve_color, 'LineWidth', 2.5);
plot(p_curve0, delta_curve0, 'Color', curve_color, 'LineWidth', 2.5, 'LineStyle', '--');

%% 坐标轴设置
ax = gca;
set(ax, 'FontName', 'Times New Roman', 'FontSize', 14, 'LineWidth', 1, 'FontWeight', 'bold');
set(ax, 'LabelFontSizeMultiplier', 1.2);  % 标签大小为刻度字体的1.2倍
xlabel('$p$', 'Interpreter', 'latex');
ylabel('$\delta$', 'Interpreter', 'latex');
xlim([0 1]);
ylim([0 1]);

%% 去掉右边和上边刻度线，保留边框
set(ax, 'Box', 'off');
xL = xlim; 
yL = ylim;
line([xL(2) xL(2)], [yL(1) yL(2)], 'Color', 'k', 'LineWidth', 1);
line([xL(1) xL(2)], [yL(2) yL(2)], 'Color', 'k', 'LineWidth', 1);

% 图例
h1 = fill(nan, nan, red_alpha, 'EdgeColor', 'none');
h2 = fill(nan, nan, blue_alpha, 'EdgeColor', 'none');
h3 = fill(nan, nan, gold_alpha, 'EdgeColor', 'none');
h4 = plot(nan, nan, 'Color', curve_color, 'LineWidth', 2.5);
h5 = plot(nan, nan, 'Color', curve_color, 'LineWidth', 2.5, 'LineStyle', '--');

legend([h1, h2, h3, h4, h5], ...
    {'All-D', 'Bistability', 'All-C' '$\lim_{p_c \to 1^-} g(p_c) = 0$', '$\lim_{p_c \to 0^+} g(p_c) = 0$'}, ...
    'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold', 'Location', 'best');

hold off;

% 保存为高质量图片
% saveas(gcf, 'Structured_Population_States.png');
% print(gcf, 'Structured_Population_States', '-depsc', '-r300');