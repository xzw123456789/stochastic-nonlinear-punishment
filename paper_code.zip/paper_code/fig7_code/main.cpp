﻿#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>
#include <random>
#include <algorithm>
#include <fstream>
#include <sstream>
using namespace std;

// ==================== 参数设置 ====================
const int L = 10;                      // 网格边长
const int G = L * L;                   // 总节点数
const int K = 4;                       // 邻居数量
const double S = 0.05;                 // 选择强度
const double BETA = 0.5;               // 惩罚强度
const double ALPHA = 0.05;             // 合作者成本
const double R = 4.75;                 // 增益因子
const double OMEGA = 1.3;              // Model 1 非线性参数
const double DELTA = 0.3;              // Model 2 非线性参数
const int TARGET_FIXATIONS = 500;      // 每个模型每个p值的目标固定次数
const int MAX_GENERATIONS = 50000;     // 单次运行最大代数
const int MAX_TOTAL_RUNS = 10000000;   // 最大总运行次数（安全限制）
const double P_START = 0.0;            // p值起始
const double P_END = 1.0;              // p值结束
const double P_STEP = 0.05;            // p值步长
// =================================================

random_device rd;
mt19937 gen(rd());

class SquareLattice {
private:
    vector<int> strategy;
    vector<double> payoff;
    vector<vector<int>> neighbors;

public:
    SquareLattice() {
        strategy.resize(G);
        payoff.resize(G);
        neighbors.resize(G);

        for (int i = 0; i < L; ++i) {
            for (int j = 0; j < L; ++j) {
                int idx = i * L + j;
                neighbors[idx].push_back(((i - 1 + L) % L) * L + j);
                neighbors[idx].push_back(((i + 1) % L) * L + j);
                neighbors[idx].push_back(i * L + ((j - 1 + L) % L));
                neighbors[idx].push_back(i * L + ((j + 1) % L));
            }
        }
    }

    void initializeSingleCooperator() {
        fill(strategy.begin(), strategy.end(), 0);
        strategy[(L / 2) * L + (L / 2)] = 1;
    }

    void calculatePayoffs_Model1() {
        const double GROUP_SIZE = K + 1.0;

        for (int i = 0; i < G; ++i) {
            int m_C = 0;
            for (int neighbor : neighbors[i]) {
                if (strategy[neighbor] == 1) m_C++;
            }

            if (strategy[i] == 1) {
                payoff[i] = R * (1 + m_C) / GROUP_SIZE - 1.0 - ALPHA;
            }
            else {
                double public_good = R * m_C / GROUP_SIZE;
                double punishment = 0.0;
                if (m_C > 0) {
                    if (abs(OMEGA - 1.0) < 1e-10) {
                        punishment = BETA * m_C / K;
                    }
                    else {
                        punishment = BETA * (1.0 - pow(OMEGA, m_C)) / (K * (1.0 - OMEGA));
                    }
                }
                payoff[i] = public_good - punishment;
            }
        }
    }

    void calculatePayoffs_Model2(double p) {
        uniform_real_distribution<> uniform(0.0, 1.0);
        const double GROUP_SIZE = K + 1.0;

        for (int i = 0; i < G; ++i) {
            int m_C = 0;
            for (int neighbor : neighbors[i]) {
                if (strategy[neighbor] == 1) m_C++;
            }

            if (strategy[i] == 1) {
                payoff[i] = R * (1 + m_C) / GROUP_SIZE - 1.0 - ALPHA;
            }
            else {
                double public_good = R * m_C / GROUP_SIZE;
                double punishment = 0.0;
                if (m_C > 0) {
                    if (abs(DELTA) < 1e-10) {
                        punishment = BETA * m_C / K;
                    }
                    else {
                        double p_high = BETA * (pow(1.0 + DELTA, m_C) - 1.0) / (K * DELTA);
                        double p_low = BETA * (1.0 - pow(1.0 - DELTA, m_C)) / (K * DELTA);
                        punishment = (uniform(gen) < p) ? p_high : p_low;
                    }
                }
                payoff[i] = public_good - punishment;
            }
        }
    }

    void birthDeathUpdate() {
        uniform_real_distribution<> prob_dis(0.0, 1.0);

        vector<double> fitness(G);
        double fitness_sum = 0.0;
        for (int i = 0; i < G; ++i) {
            fitness[i] = exp(S * payoff[i]);
            fitness_sum += fitness[i];
        }

        double rand_val = prob_dis(gen) * fitness_sum;
        double cumulative = 0.0;
        int birth_node = 0;
        for (int i = 0; i < G; ++i) {
            cumulative += fitness[i];
            if (rand_val <= cumulative) {
                birth_node = i;
                break;
            }
        }

        uniform_int_distribution<> neighbor_dis(0, neighbors[birth_node].size() - 1);
        int death_node = neighbors[birth_node][neighbor_dis(gen)];
        strategy[death_node] = strategy[birth_node];
    }

    int countCooperators() const {
        return count(strategy.begin(), strategy.end(), 1);
    }

    bool isAbsorbed() const {
        int num_C = countCooperators();
        return (num_C == 0 || num_C == G);
    }

    bool isAllCooperators() const {
        return countCooperators() == G;
    }
};

struct SimulationResult {
    int fixations, extinctions, total_runs;
    double avg_fixation_time, std_fixation_time;
    vector<int> fixation_times;

    void calculateStatistics() {
        if (fixations > 0) {
            double sum = 0.0;
            for (int t : fixation_times) sum += t;
            avg_fixation_time = sum / fixations;

            double sum_sq = 0.0;
            for (int t : fixation_times) sum_sq += pow(t - avg_fixation_time, 2);
            std_fixation_time = sqrt(sum_sq / fixations);
        }
        else {
            avg_fixation_time = 0.0;
            std_fixation_time = 0.0;
        }
    }
};

SimulationResult runMonteCarlo_Model1() {
    SimulationResult result = { 0, 0, 0, 0.0, 0.0 };

    while (result.fixations < TARGET_FIXATIONS && result.total_runs < MAX_TOTAL_RUNS) {
        SquareLattice lattice;
        lattice.initializeSingleCooperator();

        int generation = 0;
        bool absorbed = false;

        while (generation < MAX_GENERATIONS && !absorbed) {
            lattice.calculatePayoffs_Model1();
            lattice.birthDeathUpdate();
            generation++;

            if (lattice.isAbsorbed()) {
                absorbed = true;
                if (lattice.isAllCooperators()) {
                    result.fixations++;
                    result.fixation_times.push_back(generation);
                }
                else {
                    result.extinctions++;
                }
            }
        }
        result.total_runs++;

        if (result.total_runs % 10000 == 0) {
            cout << "    Model1: " << result.fixations << "/" << TARGET_FIXATIONS
                << " fixations, " << result.total_runs << " runs" << endl;
        }
    }

    result.calculateStatistics();
    return result;
}

SimulationResult runMonteCarlo_Model2(double p) {
    SimulationResult result = { 0, 0, 0, 0.0, 0.0 };

    while (result.fixations < TARGET_FIXATIONS && result.total_runs < MAX_TOTAL_RUNS) {
        SquareLattice lattice;
        lattice.initializeSingleCooperator();

        int generation = 0;
        bool absorbed = false;

        while (generation < MAX_GENERATIONS && !absorbed) {
            lattice.calculatePayoffs_Model2(p);
            lattice.birthDeathUpdate();
            generation++;

            if (lattice.isAbsorbed()) {
                absorbed = true;
                if (lattice.isAllCooperators()) {
                    result.fixations++;
                    result.fixation_times.push_back(generation);
                }
                else {
                    result.extinctions++;
                }
            }
        }
        result.total_runs++;

        if (result.total_runs % 10000 == 0) {
            cout << "    Model2 (p=" << p << "): " << result.fixations << "/" << TARGET_FIXATIONS
                << " fixations, " << result.total_runs << " runs" << endl;
        }
    }

    result.calculateStatistics();
    return result;
}

// 将p值格式化为文件名友好的字符串
string formatPValue(double p) {
    ostringstream oss;
    oss << fixed << setprecision(2) << p;
    return oss.str();
}

// 保存结果到文件（简化格式）
void saveResultsToFile(double p_val, const SimulationResult& r1, const SimulationResult& r2) {
    string filename = "fixation_p_" + formatPValue(p_val) + ".txt";
    ofstream outfile(filename);

    // 表头
    outfile << "T1\tT2" << endl;

    // 500行数据
    for (int i = 0; i < TARGET_FIXATIONS; ++i) {
        outfile << r1.fixation_times[i] << "\t" << r2.fixation_times[i] << endl;
    }

    // 空行后输出统计量
    outfile << endl;
    outfile << "Mean\t" << fixed << setprecision(2) << r1.avg_fixation_time << "\t" << r2.avg_fixation_time << endl;
    outfile << "Std\t" << fixed << setprecision(2) << r1.std_fixation_time << "\t" << r2.std_fixation_time << endl;

    outfile.close();
    cout << "  Saved to " << filename << endl;
}

int main() {
    cout << "========================================" << endl;
    cout << "Conditional Fixation Time Comparison" << endl;
    cout << "========================================" << endl;

    cout << "\nParameters:" << endl;
    cout << "  L = " << L << ", G = " << G << ", K = " << K << endl;
    cout << "  s = " << S << ", beta = " << BETA << ", alpha = " << ALPHA << endl;
    cout << "  r = " << R << ", omega = " << OMEGA << ", delta = " << DELTA << endl;
    cout << "  Target fixations: " << TARGET_FIXATIONS << endl;
    cout << "  p: " << P_START << " to " << P_END << " (step " << P_STEP << ")\n" << endl;

    // 表头
    cout << setw(8) << "p" << setw(14) << "T1" << setw(14) << "T2" << endl;
    cout << string(36, '-') << endl;

    int p_count = 0;
    int total_p = (int)((P_END - P_START) / P_STEP + 1.5);

    for (double p_val = P_START; p_val <= P_END + 1e-9; p_val += P_STEP) {
        p_count++;
        cout << "\n>>> p = " << fixed << setprecision(2) << p_val
            << " (" << p_count << "/" << total_p << ")" << endl;

        SimulationResult r1 = runMonteCarlo_Model1();
        SimulationResult r2 = runMonteCarlo_Model2(p_val);

        saveResultsToFile(p_val, r1, r2);

        cout << fixed << setprecision(2) << setw(8) << p_val
            << setw(14) << r1.avg_fixation_time
            << setw(14) << r2.avg_fixation_time << endl;
    }

    cout << "\n========================================" << endl;
    cout << "All completed! Files: fixation_p_X.XX.txt" << endl;
    cout << "========================================" << endl;

    return 0;
}